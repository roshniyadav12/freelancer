package com.freelancer.android.sdk.oauth

class OAuthException(val error: String, val reason: String) : Exception()
