package com.freelancer.android.sdk.translations

internal interface ITranslation {

    fun translate(translations: TranslationList)
}