package com.freelancer.android.sdk.models

interface JobContext : FLObject {

    var name: String?
}