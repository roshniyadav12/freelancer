package com.freelancer.android.sdk.endpoints

interface ContestMessagesApi{

    /**
     * TODO add all endpoints for contest messages
     *
     * /contests/0.1/messages
     */
}