package com.freelancer.android.sdk

internal val DEFAULT_LIMIT_VALUE: Int = 10
internal val DEFAULT_OFFSET_VALUE: Int = 0