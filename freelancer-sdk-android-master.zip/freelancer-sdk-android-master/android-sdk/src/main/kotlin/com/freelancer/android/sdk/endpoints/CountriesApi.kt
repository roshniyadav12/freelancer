package com.freelancer.android.sdk.endpoints


interface CountriesApi {

    /**
     * TODO
     *
     * add endpoint to get countries
     * /common/0.1/countries
     */
}