package com.freelancer.android.sdk.endpoints

interface ExpertGuarunteesApi{

    //TODO all endpoints here

}