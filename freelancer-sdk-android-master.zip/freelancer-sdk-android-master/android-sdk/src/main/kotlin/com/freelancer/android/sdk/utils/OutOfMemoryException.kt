package com.freelancer.android.sdk.utils

/**
 * Created by arranlomas on 21/12/17.
 */

/**
 * Exception class for OutOfMemoryError to propagate through observables
 */
class OutOfMemoryException : Exception()