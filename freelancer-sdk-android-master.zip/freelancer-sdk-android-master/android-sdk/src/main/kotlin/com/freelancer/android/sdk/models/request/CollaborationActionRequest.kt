package com.freelancer.android.sdk.models.request

data class CollaborationActionRequest(
        val action: String
)