package com.freelancer.android.sdk.models

interface FLContext : FLObject {

    var serverId: Long

    var title: String?

    var ownerId: Long

}