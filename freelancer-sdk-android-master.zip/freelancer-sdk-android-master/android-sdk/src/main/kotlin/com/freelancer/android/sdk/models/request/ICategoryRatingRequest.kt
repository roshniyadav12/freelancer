package com.freelancer.android.sdk.models.request

interface ICategoryRatingRequest